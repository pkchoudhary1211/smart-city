﻿using System;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Drawing;
using System.Data;
 



namespace smartcity
{
    
    public partial class citizenregis : System.Web.UI.Page
    {
        string date;
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false;

        }


        protected void btn1_Click(object sender, EventArgs e)
        {
            Cls ob = new Cls();

            DataTable tt = ob.SelectQuery("select * from citizenrequest where email='" + temail.Text + "'");
            if (tt.Rows.Count == 0)
            {
                if (file1.HasFile)
                {
                    string ss = Path.GetFileName(file1.PostedFile.FileName);
                    file1.PostedFile.SaveAs(Server.MapPath("~/profile/") + ss);

                    string pp = "~/profile/" + ss;
                    Image1.ImageUrl = pp.ToString();
                    date = Calendar1.SelectedDate.ToString (); 
                    ob.ExecuteQuery("insert into citizenrequest(fname,lastname,address,fathername,mothername,contact,email,city,pic,dob,password,gender,location)values('" + tfnmae.Text + "','" + tlname.Text + "','" + TextBox1.Text + "','" + tf.Text + "','" + tm.Text + "','" + tcontact.Text + "','" + temail.Text + "','" + tcity.Text + "','" + pp + "','" + Calendar1.SelectedDate + "','" + pass.Text + "','" + RadioButtonList1.SelectedItem + "','" + DropDownList1.SelectedItem + "')");
                    DataTable ta1 = ob.SelectQuery("select * from citizenrequest where email='" + temail.Text  + "'");
                    if (ta1.Rows.Count == 1)
                    {
                        Session.Add("cid", ta1.Rows[0]["email"]);
                    }
                }
                Response.Redirect("~/report.aspx");
            }
            else
            {
                Response.Write("This Id Is Already Registred"); 
            }
            
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox2.Text = Calendar1.SelectedDate.ToString(); 

            // ob.dr["idproof"] = TextBox2.Text;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (file1.HasFile)
            {
                string ss = Path.GetFileName(file1.PostedFile.FileName);
                file1.PostedFile.SaveAs(Server.MapPath("~/profile/")+ss);

                string pp = "~/profile/" + ss;
                Image1.ImageUrl = pp.ToString();
            }
        }




    }
}