﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace smartcity.citizen
{
    public partial class com : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
              
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Cls ob = new Cls ();
            string st = DateTime.Now.ToString();
            ob.ExecuteQuery("insert into complaint(coid,subject,dat,description)values('" + Session["iid"]  + "','" + TextBox1.Text + "','" +st + "','" +TextBox2.Text + "')");
            
        }
    }
}