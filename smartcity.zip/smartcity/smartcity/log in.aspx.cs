﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
namespace smartcity.Account
{
    public partial class log_in : System.Web.UI.Page
    {
        DataTable tt1 = new DataTable();
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Visible = false; 
        }

        protected void RadioButtonList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Cls ob = new Cls();
            int i=   RadioButtonList1.SelectedIndex ;
            switch (i)
            {
                case 0:


                   
                        tt1 = ob.SelectQuery("select * from citizenrequest  where email='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'");
                    if (tt1.Rows.Count == 0)
                    {
                        Label1.Visible = true;
                        Label1.Text = " Your Request is Disapproved or Invalid Id OR Password";
                    }
                    else
                    {
                      
                        Session.Add("idd", tt1.Rows [0]["email"]);
                        Session.Add("iid", tt1.Rows[0]["cid"]);
                        Response.Redirect("~/profile.aspx");

                    }
                    break;

                case 1:
                    DataTable tt2 = ob.SelectQuery("select loginId, password from adminlogin where loginId='" + TextBox1.Text + "' and password='" + TextBox2.Text + "'");
                    if (tt2.Rows.Count == 0)
                    {
                        Label1.Visible = true;
                        Label1.Text = "Invalid Id OR Password";
                    }
                    else
                    {
                        Response.Redirect("~/admin/hmepage.aspx");
                    }


                    break;
               }
            }
        }
}