﻿using System; 
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;




    public class Cls
    {
        
    public SqlConnection con = new SqlConnection ();
    public SqlCommand cmd = new SqlCommand();
    public SqlDataAdapter da = new SqlDataAdapter(); 
    public SqlDataReader srd;
    public DataSet ds = new DataSet();
    public SqlCommandBuilder scb = new SqlCommandBuilder();
    public DataRow dr;
	public Cls()
	{

        //con.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=E:\\a\\IMPORTANT PROJECTS\\pk projects\\projects\\smartcity\\smartcity\\App_Data\\smart.mdf;Integrated Security=True;User Instance=True";
        con.ConnectionString = "Data Source=.\\SQLEXPRESS;AttachDbFilename=E:\\a\\IMPORTANT PROJECTS\\pk projects\\projects\\smartcity\\smartcity\\App_Data\\smart.mdf;Integrated Security=True;User Instance=True";
        if (con.State == ConnectionState.Closed)
            con.Open();
        da.SelectCommand = cmd;
        cmd.Connection = con;


	}
    public DataTable GetRecourd(string sql)
    {
        DataTable dt = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter(sql, con);
        da.Fill(dt);
        return dt;
    }
    public void ExecuteQuery(string sql)
    {
        cmd.CommandText = sql;
        cmd.ExecuteNonQuery();
    }
    public DataTable SelectQuery(string sql)
    {
        DataTable dt = new DataTable();
        cmd.CommandText = sql;
        da.Fill(dt);
        return dt;
    }
 }
