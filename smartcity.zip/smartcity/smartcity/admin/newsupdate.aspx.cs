﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace smartcity.admin
{
    public partial class newsupdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Cls ob = new Cls();
            ob.ExecuteQuery("insert into news(news,title,upda)values('" + TextBox2.Text + "','" + DropDownList1.SelectedItem + "','" + TextBox3.Text + "')");

            TextBox3.Text = "";
            TextBox2.Text = ""; 
        }
    }
}