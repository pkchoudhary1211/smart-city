﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace smartcity.admin
{
    public partial class viewciti : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Cls ob = new Cls();
            DataTable tt = ob.SelectQuery("select * from citizenrequest");

            GridView1.DataSource = tt;
            GridView1.DataBind();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            Cls ob = new Cls();

        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }
    }
}