﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data; 
namespace smartcity
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Cls ob =  new  Cls ();
           DataTable tt= ob.SelectQuery ("select * from  citizenrequest where email='" + Session["idd"]  +"'");
            GridView1.DataSource =tt;
            GridView1.DataBind ();
        }
    }
}