﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
namespace smartcity
{
    public partial class news1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Cls ob = new Cls();
            DataTable ta1 = ob.SelectQuery("select * from news where title='Politics'");
            GridView1.DataSource = ta1;
            GridView1.DataBind();
           

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            Cls ob = new Cls();
            DataTable ta1 = ob.SelectQuery("select * from news where title='Politics'");
            GridView1.DataSource = ta1;
            GridView1.DataBind();
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Cls ob = new Cls();
            DataTable ta1 = ob.SelectQuery("select * from news where title='Sports'");
            GridView1.DataSource = ta1;
            GridView1.DataBind();
        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {
              Cls ob = new Cls();
              DataTable ta1 = ob.SelectQuery("select * from news where title='Business'");
            GridView1.DataSource = ta1;
            GridView1.DataBind();
         
        }

        protected void ImageButton4_Click(object sender, ImageClickEventArgs e)
        {
            Cls ob = new Cls();
            DataTable ta1 = ob.SelectQuery("select * from news where title='Entertainment'");
            GridView1.DataSource = ta1;
            GridView1.DataBind();
        }
    }
}